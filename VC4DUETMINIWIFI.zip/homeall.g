; homeall.g
; called to home all axes
M201 X600.00 Y600.00     ;Reduce acceleration for homing moves
M203 Z600                ;Reduce Z speed for homing moves

G91                      ;relative positioning
G1 H2 Z5 F600            ;lift Z relative to current position
G1 H1 X415 Y415 F3000    ;move quickly to X or Y endstop and stop there (first pass)
G1 H1 X415               ;home X axis
G1 H1 Y415               ;home Y axis
G1 X-3 Y-3 F600          ;go back a few mm
G1 H1 X415 F300          ;move slowly to X axis endstop once more (second pass)
G1 H1 Y415 F300          ;then move slowly to Y axis endstop

G90
G1 X227 Y140 F12000      ;Move to the center of the bed
M558 H3 F300 A1          ;Probe with low travel
G30                      ;
M558 H1 F60 A3 S0.02     ;Probe again slowly for precision
G30                      ;

G29 S1                   ;height map
M201 X16000 Y16000 Z1200 ;Accelerations
M203 Z2400               ;Return Z speed