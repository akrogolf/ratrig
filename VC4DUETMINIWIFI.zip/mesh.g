;bed mesh
G32                             ;Run bed level

M203 Z600                       ;Reduce Z speed for homing moves
M201 X1200.00 Y1200.00          ;Reduce acceleration for homing moves
;M564 S0                         ;G92 Z0; G30 S-1
M561                            ;clear any existing bed transform
G90                             ;Send absolute coordinates...
G29 S2                          ;disable mesh

;set accel
M201 X3000.0 Y3000.00

M558 T15000 H1 F120 A3 S0.03    ;T15000 set Z probe type to EZ ABL and the dive height + speeds
M557 X58:350 Y60:347 S58.4:57.4 ;GRID X-22 Y60  S60.5:65 
G29 S0                          ;run mesh and save it

M201 X16000 Y16000 Z1200        ;Accelerations
M203 Z2400                      ;Return Z speed
M98 P"homez.g"                  ;Run Home Z

;G30 P0 X58 Y60 Z-99999;
;G30 P1 X205 Y347 Z-99999 ;
;G30 P2 X350 Y60 Z-99999 S3;