G21				;Work in millimetres
G90				;Send absolute coordinates...
M83				;...but relative extruder movess

M550 P"VC2 Britney"		;Name   
M552 S1			; enable network

;Axis and motor configuration 
M569 P0 S1					;Drive 0 Z / LEFTZ
M569 P1 S1					;Drive 1 Z / REARZ
M569 P2 S1					;Drive 2 Z / RIGHTZ
M569 P3 S1					;Drive 3 Y / RIGHTXY
M569 P4 S1					;Drive 4 X / LEFTXY
M569 P5 S0					;Drive 5 Extruder
M669 K1						;corexy mode
M584 X4 Y3 Z0:1:2 E5	    ;Map X to drive 0 Y to drive 1, Z to drives 2, 3, 4, and E to drive 5

;Leadscrew locations
M671 X0:205:409  Y0:410:0 S3.0		

;Motors
M350 X16 Y16 Z16 E16 I1				;set 16x microstepping for axes with interpolation
M906 X1600 Y1600 Z1000 E1000 I30	;Set motor currents (mA)  Z1000 XY1600
M92 X80 Y80 Z800 E679       		;steps/mm 0.9 z //011722 changed E830 to E400 for LDX extruder //80->79 XY calibration

;Speed
M203 X45000 Y45000 Z2400 E7200		;Maximum speeds (mm/min) was Z1800 tr8*4
M201 X16000 Y16000 Z1200 E2000		;Accelerations (mm/s^2) e3 X8000 Y8000 Z800 E2000
M566 X1600 Y1600 Z120 E200			;Maximum jerk speeds mm/minute E60 Z60 e3 X1600 Y1600 Z80 E200

;Locations
M208 X415 Y405 Z320	S0				;set axis maxima and high homing switch positions (adjust to suit your machine)
M208 X0 Y0 Z-1 S1					;set axis minima and low homing switch positions (adjust to make X=0 and Y=0 the edges of the bed)

;End Stops
M574 X2 S1 P"io0.in"				;Map the X endstop to io0.in
M574 Y2 S1 P"io1.in"				;May the Y endstop to io1.in

;Bed
M308 S0 P"temp0" Y"thermistor" T100000 B3950 A"Bed"                     ; configure sensor 0 as thermistor on pin temp0
M950 H0 C"out0" T0 Q11				;create bed heater output on out5 and map it to sensor 0, lower switching frequency t
M570 H0 S360					    ;Hot end may be a little slow to heat up so allow it 180 seconds

;Hotend
M308 S1 P"temp1" Y"thermistor" A"RTemp" T100000 B4725 C7.06e-8 H0 L0	;duet3 e3d
M308 S2 P"temp2" Y"thermistor" A"LTemp" T100000 B4725 C7.06e-8 H0 L0	;duet3 e3d
;M308 S1 P"temp1" Y"PT1000"  ;Pt1000 located in right side of hot block
;M308 S2 P"temp2" Y"PT1000"  ;Pt1000 located in left side of hot block
M950 H1 C"out1+out2" T1 			;2 Heaters wired to separate connectors but treated as a single logical heater
M570 H1 S360					    ;Hot end may be a little slow to heat up so allow it 180 seconds
;M143 H1 S310 P1 T1 A0			    ;Monitor heaters with sensor 1
M143 H1 S310 P1 T2 A0				;Monitor heaters with sensor 2


;M308 S1 P"temp1" Y"thermistor" A"RTemp" T100000 B4725 C7.06e-8 H0 L0	;duet3 e3d
;M308 S2 P"temp2" Y"thermistor" A"LTemp" T100000 B4725 C7.06e-8 H0 L0	;duet3 e3d
;Heaters

;Fans
M950 F0 C"out3"						;Layer fan
M106 P0 S0 C"LAYER FAN";			;Layer fan
M950 F1 C"out4"                   	;Hotend fan
M106 P1 S255 H1 T50  C"HOTEND FAN"	;Enable thermostatic hotend fan (Fan turns on at 50C)
M950 F2 C"out5"                   	;LED
M106 P2 C"LED";						;LED

;Tool definitions
M563 P0 D0 H1 S"Mag+" F0			;Define Mosquito Magnum+ Tool           
G10 P0 S0 R0                      	;Set tool 0 operating and standby temperatures

;EZ ABL 
;M558 P5 C"!io6.in" I0 H4 F300 T15000 A2 S0.03  	;set Z probe type to EZ ABL and the dive height + speeds
;G31 X-20 Y-10 Z1.0 P25		                  	;Z offset can be adjusted here -1.45 -1.75 1.9 0.5

;OMRON
M558 P5 C"io6.in" I0 H4 F300 T15000 A2 S0.03  	;set Z probe type to EZ ABL and the dive height + speeds
G31 X-22 Y60 Z1.6 P25		                  	;Z offset can be adjusted here -1.45 -1.75 1.9 0.5

;Accellorometer
;M955 P0 C"io2.out+io2.in" I21 S1000 R12 Q2000000;

;Fillament Sensor
;M950 J1 C"^io4.in"; define logical input for filament auto load
;M581 P1 T2 S0 R0 ;define trigger for filament auto load triggers trigger2.g
;M950 J2 C"^io3.in"; define logical input for filament unload
;M581 P2 T3 S0 R0 ; define trigger for filament auto load triggers trigger3.g

M575 P1 S1 B57600;
M501				;load config-override
M140 H0				;Set Bed Temperature (Fast) or Configure Bed Heater      
T0					;select first hot end