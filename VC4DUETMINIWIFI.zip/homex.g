; homex.g
; called to home the X axis
M201 X600 Y600    ; Reduce acceleration for homing moves
G91                     ; Relative positioning
G1 H2 Z3 F600           ; Lift Z relative to current position
G1 H1 X415 F3000       	; Move quickly to X endstop and stop there (first pass)
G1 X-3 F600             ; Go back a few mm
G1 H1 X415 F300        	; Move slowly to X endstop once more (second pass)
M201 X6000 Y6000        ; Return to full acceleration
;G1 H2 Z-3 F600         ; Lower Z relative to current position
G90                     ; Absolute positioning
