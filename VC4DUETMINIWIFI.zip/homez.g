; homez.g
; called to home the Z axis ;M564 S0                             ;G92 Z0; G30 S-1
M201 X3000.00 Y3000.00 ;Reduce acceleration for homing moves
M203 Z600               ;Reduce Z speed for homing moves
G91                     ;relative positioning
G1 H2 Z5 F600           ;lift Z relative to current position
G90 G1 X227 Y140 F15000 ;Move to the center of the bed

M558 H3 F300 A1         ;
G30                     ;
M558 H1 F60 A3 S0.02    ;Probe again slowly for precision
G30                     ;
M201 X8000 Y8000        ;
M203 Z2400              ;
G29 S1                  ;height map

;PRINT CONDITIONS
;G29 S1							;height map
;M309 P0 S0.02 				    ;feedforward

;M303 T0 P1 S235 F0.6 A0            ;firmware retrac
;M592 D0 A0.009 B0              	;non linear extrusion
;M593 P"MZV" F45 S0.01          	;input shaper
;M572 D0 S0.025                 	;pressure advance
;M566 X450 Y450 Z80 E280        	;jerks
;M201 X8000 Y8000 Z80 E10000    	;accelerations
;M204 P4000 T8000               	;active acceleration
;M203 Z800                      	;speeds
