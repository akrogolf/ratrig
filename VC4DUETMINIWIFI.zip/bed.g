G28                          ;Home
M201 X1200.0 Y1200.00        ;Reduce acceleration for bed probing
M203 Z600                    ;Reduce Z speed for homing moves
G90                          ;Send absolute coordinates...

;set accel
M201 X3000.0 Y3000.00

M561                         ;clear any existing bed transform
M558 T15000 H2 F120 A3 S0.03 ;set Z probe type to EZ ABL and the dive height + speeds
G30 P0 X58 Y60 Z-99999       ;
G30 P1 X205 Y347 Z-99999     ;
G30 P2 X350 Y60 Z-99999 S3   ;

;set accel
M201 X3000.0 Y3000.00

M561                         ;clear any existing bed transform
M558 T15000 H2 F120 A3 S0.03 ;set Z probe type to EZ ABL and the dive height + speeds
G30 P0 X58 Y60 Z-99999       ;
G30 P1 X205 Y347 Z-99999     ;
G30 P2 X350 Y60 Z-99999 S3   ;

;G90 G1 X227 Y140 F12000    ;Move to the center of the bed
;M558 H2 F100 A3 S0.02      ;
;M851 Z0
;M500
;G31 X-22 Y60 Z1.6 P25      ;set offset

G29 S1                       ;height map
M201 X16000 Y16000 Z1200     ;Accelerations
M203 Z2400                   ;Return Z speed