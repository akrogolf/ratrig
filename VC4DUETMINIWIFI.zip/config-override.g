; config-override.g file generated in response to M500 at 2024-06-02 17:39
; This is a system-generated file - do not edit
; Heater model parameters
M307 H0 R0.429 K0.105:0.000 D7.75 E1.35 S1.00 B0
M307 H1 R2.042 K0.250:0.117 D6.47 E1.35 S1.00 B0 V23.8
; Z probe parameters
G31 K0 P25 X-22.0 Y60.0 Z1.60
; Probed tool offsets
G10 P0 Z0.000
; Workplace coordinates
G10 L2 P1 X0.00 Y0.00 Z0.00
G10 L2 P2 X0.00 Y0.00 Z0.00
G10 L2 P3 X0.00 Y0.00 Z0.00
G10 L2 P4 X0.00 Y0.00 Z0.00
G10 L2 P5 X0.00 Y0.00 Z0.00
G10 L2 P6 X0.00 Y0.00 Z0.00
G10 L2 P7 X0.00 Y0.00 Z0.00
G10 L2 P8 X0.00 Y0.00 Z0.00
G10 L2 P9 X0.00 Y0.00 Z0.00
