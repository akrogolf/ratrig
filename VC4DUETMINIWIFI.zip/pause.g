; pause.g
; called when a print from SD card is paused
M83            		; relative extruder moves
G1 E-10 F3600  		; retract 2mm of filament
G91            		; relative positioning
G1 Z5 F800			; lift Z by 10mm
G90            		; absolute positioning
G1 X200 Y395 F6000 	; go to X=0 Y=0